/**
 * ReportSection — Key findings summary and methodology overview
 */

const FINDINGS = [
  {
    number: "01",
    title: "Property Crime Dominates",
    body: "57.9% of all incidents fall under property crime, with vehicle theft being the single most common offense at 115,190 cases. Streets and sidewalks are the most frequent crime locations.",
    color: "var(--neon-blue)",
  },
  {
    number: "02",
    title: "COVID-19 Impact Visible",
    body: "A sharp 30% decline in reported incidents occurred in March–April 2020 during lockdowns. Crime rates recovered steadily through 2021–2022, peaking at 235,259 incidents in 2022.",
    color: "var(--neon-amber)",
  },
  {
    number: "03",
    title: "XGBoost Outperforms All",
    body: "XGBoost achieved 85.3% accuracy and 0.939 AUC-ROC in predicting crime severity, outperforming Random Forest (83.9%) and Logistic Regression (66.5%). Broad category and weapon usage are the top predictors.",
    color: "var(--neon-green)",
  },
  {
    number: "04",
    title: "Prophet Forecasts Best",
    body: "Facebook Prophet outperformed SARIMA with MAE of 8,664 vs 9,906. The model reveals a strong summer peak (July–August) and a February trough in annual crime seasonality.",
    color: "var(--neon-red)",
  },
  {
    number: "05",
    title: "Six Semantic Crime Themes",
    body: "LDA topic modeling on 50,000 descriptions discovered 6 coherent themes: vandalism, vehicle crimes, petty theft, violent assaults, domestic violence, and identity fraud.",
    color: "#a855f7",
  },
  {
    number: "06",
    title: "Central Division Hotspot",
    body: "Central LAPD Division records the highest volume at 69,670 incidents, followed by 77th Street (61,758) and Pacific (59,514). Five K-Means clusters reveal distinct geospatial crime profiles.",
    color: "#06b6d4",
  },
];

const PIPELINE = [
  { step: "01", label: "Data Ingestion", desc: "1,004,991 records loaded from LAPD Open Data Portal" },
  { step: "02", label: "Preprocessing", desc: "14 engineered features, missing value treatment, encoding" },
  { step: "03", label: "EDA", desc: "20 visualizations across temporal, spatial, and demographic dimensions" },
  { step: "04", label: "ML Classification", desc: "LR, RF, XGBoost trained on 200K samples with stratified split" },
  { step: "05", label: "Clustering", desc: "MiniBatch K-Means (k=5) on 100K geospatial samples" },
  { step: "06", label: "Time Series", desc: "SARIMA and Prophet 12-month forecasts evaluated on 2024 data" },
  { step: "07", label: "NLP", desc: "TF-IDF, bigrams, LDA on 50K crime descriptions" },
];

export default function ReportSection() {
  return (
    <section id="report" className="py-20">
      <div className="container">
        {/* Header */}
        <div className="mb-12">
          <div className="data-mono text-xs tracking-widest uppercase mb-2" style={{ color: "var(--neon-blue)" }}>
            // SECTION 06
          </div>
          <h2 className="display-heading text-3xl md:text-4xl mb-3" style={{ color: "oklch(0.93 0.008 220)" }}>
            Key Findings & Methodology
          </h2>
          <p className="text-sm max-w-2xl" style={{ color: "oklch(0.65 0.015 220)" }}>
            Summary of the most significant insights derived from the comprehensive analysis of LAPD crime data.
          </p>
          <div className="section-divider mt-4 max-w-xs" />
        </div>

        {/* Findings grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5 mb-16">
          {FINDINGS.map((f, i) => (
            <div
              key={i}
              className="data-card rounded-lg p-5 relative overflow-hidden"
            >
              <div
                className="data-mono text-4xl font-bold absolute top-4 right-4 opacity-10"
                style={{ color: f.color }}
              >
                {f.number}
              </div>
              <div
                className="data-mono text-xs font-bold mb-2"
                style={{ color: f.color }}
              >
                FINDING {f.number}
              </div>
              <h3
                className="display-heading text-base font-semibold mb-2"
                style={{ color: "oklch(0.90 0.008 220)" }}
              >
                {f.title}
              </h3>
              <p
                className="text-sm leading-relaxed"
                style={{ color: "oklch(0.60 0.015 220)" }}
              >
                {f.body}
              </p>
            </div>
          ))}
        </div>

        {/* Pipeline */}
        <div
          className="rounded-lg p-6 md:p-8"
          style={{ background: "var(--surface-1)", border: "1px solid var(--border)" }}
        >
          <h3
            className="display-heading text-xl mb-6"
            style={{ color: "oklch(0.93 0.008 220)" }}
          >
            Analytical Pipeline
          </h3>
          <div className="relative">
            {/* Vertical line */}
            <div
              className="absolute left-5 top-0 bottom-0 w-px"
              style={{ background: "rgba(0,212,255,0.2)" }}
            />
            <div className="space-y-5">
              {PIPELINE.map((p, i) => (
                <div key={i} className="flex items-start gap-4 pl-12 relative">
                  <div
                    className="absolute left-0 w-10 h-10 rounded-full flex items-center justify-center data-mono text-xs font-bold flex-shrink-0"
                    style={{
                      background: "rgba(0,212,255,0.1)",
                      border: "1px solid rgba(0,212,255,0.3)",
                      color: "var(--neon-blue)",
                    }}
                  >
                    {p.step}
                  </div>
                  <div>
                    <div
                      className="font-semibold text-sm mb-0.5"
                      style={{ color: "oklch(0.88 0.008 220)" }}
                    >
                      {p.label}
                    </div>
                    <div
                      className="text-xs"
                      style={{ color: "oklch(0.55 0.015 220)" }}
                    >
                      {p.desc}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* References */}
        <div className="mt-10 p-5 rounded-lg" style={{ background: "var(--surface-1)", border: "1px solid var(--border)" }}>
          <h3 className="display-heading text-base font-semibold mb-3" style={{ color: "oklch(0.90 0.008 220)" }}>
            References
          </h3>
          <ul className="space-y-1">
            {[
              { num: 1, text: "City of Los Angeles Open Data Portal. (2025). Crime Data from 2020 to Present.", url: "https://data.lacity.org" },
              { num: 2, text: "Pedregosa, F., et al. (2011). Scikit-learn: Machine Learning in Python. JMLR, 12, 2825–2830." },
              { num: 3, text: "Taylor, S. J., & Letham, B. (2018). Forecasting at Scale. The American Statistician, 72(1), 37–45." },
              { num: 4, text: "Chen, T., & Guestrin, C. (2016). XGBoost: A Scalable Tree Boosting System. KDD 2016." },
            ].map((r) => (
              <li key={r.num} className="text-xs flex gap-2" style={{ color: "oklch(0.55 0.015 220)" }}>
                <span className="data-mono" style={{ color: "var(--neon-blue)", flexShrink: 0 }}>[{r.num}]</span>
                <span>{r.text}{r.url && <> — <a href={r.url} target="_blank" rel="noopener noreferrer" style={{ color: "var(--neon-blue)" }}>{r.url}</a></>}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
