/**
 * TimeSeriesSection — SARIMA and Prophet forecasting results
 */
import { useState } from "react";

const TS_CHARTS = [
  {
    title: "Seasonal Decomposition",
    src: "/manus-storage/fig29_seasonal_decomposition_da4b0eb1.png",
    desc: "Decomposition reveals a clear yearly seasonal pattern and a downward trend post-2022.",
  },
  {
    title: "ACF & PACF Plots",
    src: "/manus-storage/fig30_acf_pacf_34516363.png",
    desc: "Autocorrelation and partial autocorrelation plots used to identify SARIMA parameters.",
  },
  {
    title: "SARIMA Forecast",
    src: "/manus-storage/fig31_sarima_forecast_6c53e749.png",
    desc: "SARIMA(1,1,1)(1,1,1,12) 12-month forecast with 95% confidence intervals.",
  },
  {
    title: "Prophet Forecast",
    src: "/manus-storage/fig32_prophet_forecast_b38ae021.png",
    desc: "Prophet model forecast with uncertainty bands — outperforms SARIMA on test set.",
  },
  {
    title: "Prophet Components",
    src: "/manus-storage/fig33_prophet_components_b21ce642.png",
    desc: "Trend, yearly seasonality, and holiday effects decomposed by the Prophet model.",
  },
  {
    title: "Model Comparison",
    src: "/manus-storage/fig34_ts_model_comparison_26d94052.png",
    desc: "SARIMA vs. Prophet: Prophet achieves lower MAE (8,664 vs 9,906) and RMSE.",
  },
];

const METRICS = [
  { model: "SARIMA", mae: "9,906", rmse: "11,015", mape: "—", color: "var(--neon-blue)" },
  { model: "Prophet", mae: "8,664", rmse: "9,786", mape: "Best", color: "var(--neon-green)", best: true },
];

export default function TimeSeriesSection() {
  const [lightbox, setLightbox] = useState<string | null>(null);

  return (
    <section id="timeseries" className="py-20">
      <div className="container">
        <div className="mb-10">
          <div className="data-mono text-xs tracking-widest uppercase mb-2" style={{ color: "var(--neon-green)" }}>
            // SECTION 04
          </div>
          <h2 className="display-heading text-3xl md:text-4xl mb-3" style={{ color: "oklch(0.93 0.008 220)" }}>
            Time Series Forecasting
          </h2>
          <p className="text-sm max-w-2xl" style={{ color: "oklch(0.65 0.015 220)" }}>
            Monthly crime volume forecasting using SARIMA and Facebook Prophet, trained on 2020–2023 data and evaluated on 2024.
          </p>
          <div className="section-divider mt-4 max-w-xs" style={{ background: "linear-gradient(90deg, transparent, rgba(16,185,129,0.4), transparent)" }} />
        </div>

        {/* Metrics table */}
        <div className="grid md:grid-cols-2 gap-4 mb-10 max-w-2xl">
          {METRICS.map((m, i) => (
            <div
              key={i}
              className="rounded-lg p-5"
              style={{
                background: "var(--surface-1)",
                border: m.best ? `1px solid ${m.color}` : "1px solid var(--border)",
                boxShadow: m.best ? `0 0 20px rgba(16,185,129,0.12)` : "none",
              }}
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="display-heading text-base font-semibold" style={{ color: "oklch(0.90 0.008 220)" }}>
                  {m.model}
                </h3>
                {m.best && (
                  <span className="text-xs px-2 py-0.5 rounded-full data-mono" style={{ background: "rgba(16,185,129,0.15)", color: "var(--neon-green)", border: "1px solid rgba(16,185,129,0.3)" }}>
                    BEST
                  </span>
                )}
              </div>
              <div className="grid grid-cols-3 gap-3">
                {[{ label: "MAE", val: m.mae }, { label: "RMSE", val: m.rmse }, { label: "Rank", val: m.mape }].map((stat, j) => (
                  <div key={j}>
                    <div className="text-xs mb-0.5" style={{ color: "oklch(0.55 0.015 220)" }}>{stat.label}</div>
                    <div className="data-mono text-base font-bold" style={{ color: m.color }}>{stat.val}</div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Charts */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {TS_CHARTS.map((chart, i) => (
            <div key={i} className="data-card rounded-lg overflow-hidden cursor-pointer" onClick={() => setLightbox(chart.src)}>
              <div style={{ background: "oklch(0.08 0.010 260)" }}>
                <img src={chart.src} alt={chart.title} className="chart-img" loading="lazy" />
              </div>
              <div className="p-4">
                <h3 className="text-sm font-semibold mb-1" style={{ color: "oklch(0.90 0.008 220)" }}>{chart.title}</h3>
                <p className="text-xs leading-relaxed" style={{ color: "oklch(0.55 0.015 220)" }}>{chart.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {lightbox && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(0,0,0,0.92)" }} onClick={() => setLightbox(null)}>
          <img src={lightbox} alt="Chart" className="max-w-full max-h-full rounded-lg" style={{ boxShadow: "0 0 40px rgba(16,185,129,0.2)" }} />
          <button className="absolute top-4 right-4 text-white text-2xl font-bold" onClick={() => setLightbox(null)}>×</button>
        </div>
      )}
    </section>
  );
}
