/**
 * MLSection — Machine Learning models: classification + clustering
 */
import { useState } from "react";

const MODEL_RESULTS = [
  {
    name: "Logistic Regression",
    accuracy: 66.45,
    auc: 0.7964,
    f1: 0.7569,
    color: "var(--neon-blue)",
    bar: 66,
  },
  {
    name: "Random Forest",
    accuracy: 83.98,
    auc: 0.9293,
    f1: 0.8634,
    color: "var(--neon-amber)",
    bar: 84,
  },
  {
    name: "XGBoost",
    accuracy: 85.30,
    auc: 0.9387,
    f1: 0.8737,
    color: "var(--neon-green)",
    bar: 85,
    best: true,
  },
];

const ML_CHARTS = [
  {
    title: "ROC Curves — All Models",
    src: "/manus-storage/fig21_roc_curves_027e8de2.png",
    desc: "XGBoost achieves the highest AUC of 0.939, demonstrating strong discriminative ability.",
  },
  {
    title: "Confusion Matrices",
    src: "/manus-storage/fig22_confusion_matrices_3434ac5e.png",
    desc: "XGBoost misclassifies the fewest instances across both Part 1 and Part 2 crime classes.",
  },
  {
    title: "Feature Importance (Random Forest)",
    src: "/manus-storage/fig23_feature_importance_rf_c6d0d478.png",
    desc: "Broad category, weapon usage, and premise type are the strongest predictors of severity.",
  },
  {
    title: "Model Comparison",
    src: "/manus-storage/fig24_model_comparison_16ae268c.png",
    desc: "Side-by-side comparison of Accuracy, AUC, and F1-Score across all three models.",
  },
  {
    title: "K-Means Elbow Curve",
    src: "/manus-storage/fig25_kmeans_elbow_4c636a28.png",
    desc: "The elbow method identifies k=5 as the optimal number of crime clusters.",
  },
  {
    title: "Cluster Geographic Map",
    src: "/manus-storage/fig26_cluster_map_3198f3c8.png",
    desc: "Five distinct crime clusters mapped geographically across Los Angeles.",
  },
  {
    title: "Cluster Profiles",
    src: "/manus-storage/fig27_cluster_profiles_cdfda51d.png",
    desc: "Feature profiles for each cluster reveal distinct behavioral and geographic patterns.",
  },
  {
    title: "PCA Cluster Visualization",
    src: "/manus-storage/fig28_pca_clusters_64ac9a51.png",
    desc: "Principal Component Analysis reduces dimensionality to visualize cluster separation.",
  },
];

export default function MLSection() {
  const [lightbox, setLightbox] = useState<string | null>(null);

  return (
    <section
      id="ml"
      className="py-20"
      style={{ background: "oklch(0.12 0.013 260)" }}
    >
      <div className="container">
        {/* Header */}
        <div className="mb-10">
          <div
            className="data-mono text-xs tracking-widest uppercase mb-2"
            style={{ color: "var(--neon-amber)" }}
          >
            // SECTION 03
          </div>
          <h2
            className="display-heading text-3xl md:text-4xl mb-3"
            style={{ color: "oklch(0.93 0.008 220)" }}
          >
            Machine Learning
          </h2>
          <p
            className="text-sm max-w-2xl"
            style={{ color: "oklch(0.65 0.015 220)" }}
          >
            Binary classification of crime severity (Part 1 vs Part 2) using
            three models trained on 200,000 samples, plus K-Means clustering to
            discover latent crime patterns.
          </p>
          <div
            className="section-divider mt-4 max-w-xs"
            style={{
              background:
                "linear-gradient(90deg, transparent, rgba(245,158,11,0.4), transparent)",
            }}
          />
        </div>

        {/* Model comparison cards */}
        <div className="grid md:grid-cols-3 gap-5 mb-12">
          {MODEL_RESULTS.map((m, i) => (
            <div
              key={i}
              className="rounded-lg p-5 relative overflow-hidden"
              style={{
                background: "var(--surface-1)",
                border: m.best
                  ? `1px solid ${m.color}`
                  : "1px solid var(--border)",
                boxShadow: m.best
                  ? `0 0 20px rgba(16,185,129,0.15)`
                  : "none",
              }}
            >
              {m.best && (
                <span
                  className="absolute top-3 right-3 text-xs px-2 py-0.5 rounded-full data-mono font-medium"
                  style={{
                    background: "rgba(16,185,129,0.15)",
                    color: "var(--neon-green)",
                    border: "1px solid rgba(16,185,129,0.3)",
                  }}
                >
                  BEST
                </span>
              )}
              <h3
                className="display-heading text-base font-semibold mb-4"
                style={{ color: "oklch(0.90 0.008 220)" }}
              >
                {m.name}
              </h3>

              {/* Accuracy bar */}
              <div className="mb-4">
                <div className="flex justify-between text-xs mb-1">
                  <span style={{ color: "oklch(0.55 0.015 220)" }}>
                    Accuracy
                  </span>
                  <span
                    className="data-mono font-medium"
                    style={{ color: m.color }}
                  >
                    {m.accuracy.toFixed(2)}%
                  </span>
                </div>
                <div
                  className="h-2 rounded-full overflow-hidden"
                  style={{ background: "var(--surface-3)" }}
                >
                  <div
                    className="h-full rounded-full transition-all duration-1000"
                    style={{
                      width: `${m.bar}%`,
                      background: m.color,
                      boxShadow: `0 0 8px ${m.color}`,
                    }}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div
                    className="text-xs mb-0.5"
                    style={{ color: "oklch(0.55 0.015 220)" }}
                  >
                    AUC-ROC
                  </div>
                  <div
                    className="data-mono text-lg font-bold"
                    style={{ color: m.color }}
                  >
                    {m.auc}
                  </div>
                </div>
                <div>
                  <div
                    className="text-xs mb-0.5"
                    style={{ color: "oklch(0.55 0.015 220)" }}
                  >
                    F1-Score
                  </div>
                  <div
                    className="data-mono text-lg font-bold"
                    style={{ color: m.color }}
                  >
                    {m.f1}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Chart grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          {ML_CHARTS.map((chart, i) => (
            <div
              key={i}
              className="data-card rounded-lg overflow-hidden cursor-pointer"
              onClick={() => setLightbox(chart.src)}
            >
              <div style={{ background: "oklch(0.08 0.010 260)" }}>
                <img
                  src={chart.src}
                  alt={chart.title}
                  className="chart-img"
                  loading="lazy"
                />
              </div>
              <div className="p-3">
                <h3
                  className="text-xs font-semibold mb-1"
                  style={{ color: "oklch(0.85 0.008 220)" }}
                >
                  {chart.title}
                </h3>
                <p
                  className="text-xs leading-relaxed"
                  style={{ color: "oklch(0.50 0.015 220)" }}
                >
                  {chart.desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {lightbox && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ background: "rgba(0,0,0,0.92)" }}
          onClick={() => setLightbox(null)}
        >
          <img
            src={lightbox}
            alt="Chart"
            className="max-w-full max-h-full rounded-lg"
            style={{ boxShadow: "0 0 40px rgba(245,158,11,0.2)" }}
          />
          <button
            className="absolute top-4 right-4 text-white text-2xl font-bold"
            onClick={() => setLightbox(null)}
          >
            ×
          </button>
        </div>
      )}
    </section>
  );
}
