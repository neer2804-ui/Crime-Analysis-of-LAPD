/**
 * NLPSection — NLP analysis: word clouds, TF-IDF, bigrams, LDA topics
 */
import { useState } from "react";

const LDA_TOPICS = [
  { id: 1, label: "Vandalism & Property Damage", words: ["vandalism", "damage", "window", "paint", "graffiti", "fence", "wall"], color: "var(--neon-blue)" },
  { id: 2, label: "Vehicle-Related Crimes", words: ["vehicle", "stolen", "motor", "auto", "car", "truck", "catalytic"], color: "var(--neon-amber)" },
  { id: 3, label: "Petty Theft & Shoplifting", words: ["petty", "theft", "shoplifting", "store", "merchandise", "retail", "under"], color: "var(--neon-green)" },
  { id: 4, label: "Violent Assaults", words: ["assault", "weapon", "deadly", "aggravated", "firearm", "knife", "bodily"], color: "var(--neon-red)" },
  { id: 5, label: "Domestic Violence", words: ["intimate", "partner", "domestic", "simple", "battery", "spousal", "cohabitant"], color: "#a855f7" },
  { id: 6, label: "Identity Theft & Fraud", words: ["identity", "fraud", "forgery", "document", "credit", "financial", "false"], color: "#06b6d4" },
];

const NLP_CHARTS = [
  {
    title: "Word Cloud — All Crimes",
    src: "/manus-storage/fig35_wordcloud_all_fad92046.png",
    desc: "Most frequent terms in LAPD crime descriptions after stopword removal and lemmatization.",
    wide: true,
  },
  {
    title: "Top 30 Words",
    src: "/manus-storage/fig36_top30_words_f883b574.png",
    desc: "Bar chart of the 30 most frequent lemmatized tokens across all crime descriptions.",
  },
  {
    title: "TF-IDF by Category",
    src: "/manus-storage/fig37_tfidf_by_category_ade8be14.png",
    desc: "Top TF-IDF terms per crime category, revealing category-specific vocabulary.",
  },
  {
    title: "Bigram Analysis",
    src: "/manus-storage/fig38_bigrams_fe668495.png",
    desc: "Most frequent two-word phrases, capturing compound crime descriptors.",
  },
  {
    title: "LDA Topic Distribution",
    src: "/manus-storage/fig39_lda_topics_2ab323a6.png",
    desc: "6-topic LDA model trained on 50,000 crime descriptions reveals coherent themes.",
  },
  {
    title: "Word Clouds by Category",
    src: "/manus-storage/fig40_wordclouds_by_category_645b6672.png",
    desc: "Individual word clouds for each broad crime category.",
    wide: true,
  },
];

export default function NLPSection() {
  const [lightbox, setLightbox] = useState<string | null>(null);
  const [activeTopic, setActiveTopic] = useState(0);

  return (
    <section id="nlp" className="py-20" style={{ background: "oklch(0.12 0.013 260)" }}>
      <div className="container">
        <div className="mb-10">
          <div className="data-mono text-xs tracking-widest uppercase mb-2" style={{ color: "var(--neon-red)" }}>
            // SECTION 05
          </div>
          <h2 className="display-heading text-3xl md:text-4xl mb-3" style={{ color: "oklch(0.93 0.008 220)" }}>
            Natural Language Processing
          </h2>
          <p className="text-sm max-w-2xl" style={{ color: "oklch(0.65 0.015 220)" }}>
            Semantic analysis of 1,004,991 crime descriptions using TF-IDF, bigram extraction, and Latent Dirichlet Allocation topic modeling.
          </p>
          <div className="section-divider mt-4 max-w-xs" style={{ background: "linear-gradient(90deg, transparent, rgba(239,68,68,0.4), transparent)" }} />
        </div>

        {/* LDA Topics */}
        <div className="mb-12">
          <h3 className="display-heading text-xl mb-5" style={{ color: "oklch(0.90 0.008 220)" }}>
            LDA Topic Model — 6 Discovered Themes
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {LDA_TOPICS.map((topic, i) => (
              <div
                key={i}
                className="rounded-lg p-4 cursor-pointer transition-all duration-200"
                style={{
                  background: activeTopic === i ? `rgba(${topic.color === "var(--neon-blue)" ? "0,212,255" : topic.color === "var(--neon-amber)" ? "245,158,11" : topic.color === "var(--neon-green)" ? "16,185,129" : topic.color === "var(--neon-red)" ? "239,68,68" : topic.color === "#a855f7" ? "168,85,247" : "6,182,212"},0.08)` : "var(--surface-1)",
                  border: activeTopic === i ? `1px solid ${topic.color}` : "1px solid var(--border)",
                }}
                onClick={() => setActiveTopic(i)}
              >
                <div className="flex items-center gap-2 mb-3">
                  <span className="data-mono text-xs font-bold" style={{ color: topic.color }}>
                    TOPIC {topic.id}
                  </span>
                </div>
                <h4 className="text-sm font-semibold mb-2" style={{ color: "oklch(0.88 0.008 220)" }}>
                  {topic.label}
                </h4>
                <div className="flex flex-wrap gap-1">
                  {topic.words.map((w, j) => (
                    <span
                      key={j}
                      className="text-xs px-2 py-0.5 rounded data-mono"
                      style={{
                        background: "var(--surface-3)",
                        color: "oklch(0.65 0.015 220)",
                      }}
                    >
                      {w}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* NLP Charts */}
        <div className="grid md:grid-cols-2 gap-5">
          {NLP_CHARTS.map((chart, i) => (
            <div
              key={i}
              className={`data-card rounded-lg overflow-hidden cursor-pointer ${chart.wide ? "md:col-span-2" : ""}`}
              onClick={() => setLightbox(chart.src)}
            >
              <div style={{ background: "oklch(0.08 0.010 260)" }}>
                <img src={chart.src} alt={chart.title} className="chart-img" loading="lazy" />
              </div>
              <div className="p-4">
                <h3 className="text-sm font-semibold mb-1" style={{ color: "oklch(0.90 0.008 220)" }}>{chart.title}</h3>
                <p className="text-xs leading-relaxed" style={{ color: "oklch(0.55 0.015 220)" }}>{chart.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {lightbox && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: "rgba(0,0,0,0.92)" }} onClick={() => setLightbox(null)}>
          <img src={lightbox} alt="Chart" className="max-w-full max-h-full rounded-lg" style={{ boxShadow: "0 0 40px rgba(239,68,68,0.2)" }} />
          <button className="absolute top-4 right-4 text-white text-2xl font-bold" onClick={() => setLightbox(null)}>×</button>
        </div>
      )}
    </section>
  );
}
