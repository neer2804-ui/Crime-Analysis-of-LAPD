/**
 * HeroSection — Full-bleed dark hero with animated scan line and typographic statement
 */
import { useEffect, useState } from "react";
import { ChevronDown } from "lucide-react";

const STATS = [
  { value: "1,004,991", label: "Total Incidents" },
  { value: "2020–2025", label: "Data Period" },
  { value: "21", label: "LAPD Areas" },
  { value: "140", label: "Crime Types" },
];

export default function HeroSection() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 100);
    return () => clearTimeout(t);
  }, []);

  return (
    <section
      id="hero"
      className="relative min-h-screen flex flex-col justify-center overflow-hidden"
      style={{
        background:
          "radial-gradient(ellipse at 20% 50%, rgba(0,212,255,0.06) 0%, transparent 60%), radial-gradient(ellipse at 80% 20%, rgba(245,158,11,0.04) 0%, transparent 50%), oklch(0.10 0.012 260)",
      }}
    >
      {/* Scan line */}
      <div className="scanline" />

      {/* Grid overlay */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(rgba(0,212,255,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(0,212,255,0.03) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
        }}
      />

      {/* Content */}
      <div className="container relative z-10 pt-24 pb-16">
        <div
          className={`transition-all duration-1000 ${
            visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          {/* Badge */}
          <div className="flex items-center gap-2 mb-6">
            <span
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium data-mono border"
              style={{
                color: "var(--neon-blue)",
                borderColor: "rgba(0,212,255,0.3)",
                background: "rgba(0,212,255,0.08)",
              }}
            >
              <span
                className="w-1.5 h-1.5 rounded-full pulse-dot"
                style={{ background: "var(--neon-blue)" }}
              />
              LIVE ANALYSIS · LOS ANGELES, CA
            </span>
          </div>

          {/* Main heading */}
          <h1
            className="display-heading text-5xl md:text-7xl lg:text-8xl leading-none mb-4 tracking-tight"
            style={{ color: "oklch(0.95 0.008 220)" }}
          >
            LAPD CRIME
            <br />
            <span
              className="neon-blue"
              style={{
                WebkitTextStroke: "1px rgba(0,212,255,0.3)",
              }}
            >
              ANALYTICS
            </span>
          </h1>

          {/* Subtitle */}
          <p
            className="text-lg md:text-xl max-w-2xl mb-10 leading-relaxed"
            style={{ color: "oklch(0.65 0.015 220)" }}
          >
            A comprehensive data science investigation of{" "}
            <strong style={{ color: "oklch(0.85 0.010 220)" }}>
              1,004,991 crime incidents
            </strong>{" "}
            reported to the Los Angeles Police Department from 2020 to 2025 —
            featuring EDA, machine learning, time series forecasting, and NLP
            analysis.
          </p>

          {/* CTA */}
          <div className="flex flex-wrap gap-4 mb-16">
            <button
              onClick={() =>
                document
                  .getElementById("overview")
                  ?.scrollIntoView({ behavior: "smooth" })
              }
              className="px-6 py-3 rounded font-medium text-sm transition-all duration-200"
              style={{
                background: "var(--neon-blue)",
                color: "#0d1117",
                boxShadow: "0 0 20px rgba(0,212,255,0.3)",
              }}
              onMouseEnter={(e) =>
                (e.currentTarget.style.boxShadow =
                  "0 0 30px rgba(0,212,255,0.5)")
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.boxShadow =
                  "0 0 20px rgba(0,212,255,0.3)")
              }
            >
              Explore Analysis
            </button>
            <button
              onClick={() =>
                document
                  .getElementById("report")
                  ?.scrollIntoView({ behavior: "smooth" })
              }
              className="px-6 py-3 rounded font-medium text-sm border transition-all duration-200"
              style={{
                borderColor: "rgba(0,212,255,0.3)",
                color: "var(--neon-blue)",
                background: "rgba(0,212,255,0.05)",
              }}
            >
              View Report
            </button>
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {STATS.map((s, i) => (
              <div
                key={i}
                className="data-card p-4"
                style={{ animationDelay: `${i * 0.1}s` }}
              >
                <div
                  className="data-mono text-xl sm:text-2xl font-bold mb-1"
                  style={{ color: "var(--neon-blue)" }}
                >
                  {s.value}
                </div>
                <div
                  className="text-xs uppercase tracking-widest"
                  style={{ color: "oklch(0.55 0.015 220)" }}
                >
                  {s.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce">
        <span
          className="text-xs tracking-widest uppercase"
          style={{ color: "oklch(0.45 0.015 220)" }}
        >
          Scroll
        </span>
        <ChevronDown
          className="w-4 h-4"
          style={{ color: "oklch(0.45 0.015 220)" }}
        />
      </div>
    </section>
  );
}
