/**
 * EDASection — Exploratory Data Analysis with tabbed chart gallery
 * Design: Dark Intelligence / Data Noir
 */
import { useState } from "react";

const EDA_TABS = [
  {
    id: "crime-types",
    label: "Crime Types",
    charts: [
      {
        title: "Top 20 Crime Types",
        src: "/manus-storage/fig01_top20_crimes_944ffbab.png",
        desc: "Vehicle theft dominates with 115,190 incidents, followed by simple assault and burglary from vehicle.",
      },
      {
        title: "Crime Category Breakdown",
        src: "/manus-storage/fig02_broad_categories_6c9a7f67.png",
        desc: "Property crimes account for 57.9% of all incidents. Violent crimes represent 20.9%.",
      },
      {
        title: "Crime Severity Distribution",
        src: "/manus-storage/fig16_status_distribution_a4d4ab4a.png",
        desc: "60% of incidents are classified as Part 1 (Serious) crimes under FBI classification.",
      },
    ],
  },
  {
    id: "temporal",
    label: "Temporal",
    charts: [
      {
        title: "Monthly Crime Trend (2020–2025)",
        src: "/manus-storage/fig03_monthly_trend_470f3015.png",
        desc: "Sharp dip in March–April 2020 during COVID-19 lockdowns, followed by steady recovery through 2022–2023.",
      },
      {
        title: "Annual Crime Count",
        src: "/manus-storage/fig04_yearly_crimes_01fc6af8.png",
        desc: "Crime volume peaked in 2022 with 235,259 incidents and has been declining since.",
      },
      {
        title: "Crimes by Hour of Day",
        src: "/manus-storage/fig05_hourly_crimes_7e0ce0e0.png",
        desc: "Incidents peak at noon and again around midnight, with the lowest activity between 3–5 AM.",
      },
      {
        title: "Crimes by Day of Week",
        src: "/manus-storage/fig06_day_of_week_bea4a1cc.png",
        desc: "Friday and Saturday see the highest incident volumes; Sunday is the quietest day.",
      },
      {
        title: "Day × Hour Heatmap",
        src: "/manus-storage/fig11_heatmap_dow_hour_0f032c82.png",
        desc: "The heatmap reveals Friday evenings and Saturday nights as the highest-risk time windows.",
      },
      {
        title: "Time of Day Distribution",
        src: "/manus-storage/fig18_time_of_day_50a63e4b.png",
        desc: "Afternoon and evening periods account for the majority of reported incidents.",
      },
      {
        title: "Monthly Trends by Category",
        src: "/manus-storage/fig15_monthly_by_category_383b0c8c.png",
        desc: "Property crimes show the strongest seasonal variation, peaking in summer months.",
      },
      {
        title: "Year-over-Year: Top 5 Crimes",
        src: "/manus-storage/fig19_yoy_top5_crimes_119581f0.png",
        desc: "Vehicle theft surged significantly in 2021–2022 before stabilizing.",
      },
    ],
  },
  {
    id: "geography",
    label: "Geography",
    charts: [
      {
        title: "Crimes by LAPD Area",
        src: "/manus-storage/fig07_area_crimes_5de36aa4.png",
        desc: "Central Division leads with 69,670 incidents. 77th Street and Pacific follow closely.",
      },
      {
        title: "Geographic Scatter Plot",
        src: "/manus-storage/fig20_geographic_scatter_4df787c4.png",
        desc: "Spatial distribution of incidents across Los Angeles, color-coded by crime category.",
      },
      {
        title: "Severity by Area",
        src: "/manus-storage/fig14_severity_by_area_51f8c6b8.png",
        desc: "Central and 77th Street divisions have the highest proportion of serious (Part 1) crimes.",
      },
    ],
  },
  {
    id: "demographics",
    label: "Demographics",
    charts: [
      {
        title: "Victim Age Distribution",
        src: "/manus-storage/fig08_victim_age_2e6b6d10.png",
        desc: "Victims are concentrated in the 20–39 age bracket, with a secondary peak at 30–35.",
      },
      {
        title: "Victim Sex",
        src: "/manus-storage/fig09_victim_sex_6f3a19a8.png",
        desc: "Male victims (53%) slightly outnumber female victims (47%) across all crime types.",
      },
      {
        title: "Victim Descent Groups",
        src: "/manus-storage/fig10_victim_descent_35d39218.png",
        desc: "Hispanic/Latin/Mexican and White victims are the most frequently reported descent groups.",
      },
    ],
  },
  {
    id: "other",
    label: "Premises & Weapons",
    charts: [
      {
        title: "Top Premises",
        src: "/manus-storage/fig12_top_premises_b0e86da2.png",
        desc: "Streets and sidewalks are the most common crime locations, followed by single-family dwellings.",
      },
      {
        title: "Weapon Usage",
        src: "/manus-storage/fig13_weapons_515d4412.png",
        desc: "Strong-arm (hands/fists) is the most common weapon type, followed by handguns.",
      },
      {
        title: "Correlation Heatmap",
        src: "/manus-storage/fig17_correlation_heatmap_8c72a25d.png",
        desc: "Feature correlation matrix showing relationships between numerical variables.",
      },
    ],
  },
];

export default function EDASection() {
  const [activeTab, setActiveTab] = useState("crime-types");
  const [lightbox, setLightbox] = useState<string | null>(null);

  const activeCharts =
    EDA_TABS.find((t) => t.id === activeTab)?.charts ?? [];

  return (
    <section id="eda" className="py-20">
      <div className="container">
        {/* Header */}
        <div className="mb-10">
          <div
            className="data-mono text-xs tracking-widest uppercase mb-2"
            style={{ color: "var(--neon-blue)" }}
          >
            // SECTION 02
          </div>
          <h2
            className="display-heading text-3xl md:text-4xl mb-3"
            style={{ color: "oklch(0.93 0.008 220)" }}
          >
            Exploratory Data Analysis
          </h2>
          <p
            className="text-sm max-w-2xl"
            style={{ color: "oklch(0.65 0.015 220)" }}
          >
            20 visualizations revealing temporal patterns, geographic hotspots,
            demographic profiles, and crime typology across Los Angeles.
          </p>
          <div className="section-divider mt-4 max-w-xs" />
        </div>

        {/* Tabs */}
        <div className="flex flex-wrap gap-2 mb-8">
          {EDA_TABS.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className="px-4 py-2 rounded text-xs font-medium uppercase tracking-wider transition-all duration-200"
              style={
                activeTab === tab.id
                  ? {
                      background: "rgba(0,212,255,0.15)",
                      color: "var(--neon-blue)",
                      border: "1px solid rgba(0,212,255,0.4)",
                    }
                  : {
                      background: "var(--surface-1)",
                      color: "oklch(0.55 0.015 220)",
                      border: "1px solid var(--border)",
                    }
              }
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Chart grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {activeCharts.map((chart, i) => (
            <div
              key={i}
              className="data-card rounded-lg overflow-hidden cursor-pointer"
              onClick={() => setLightbox(chart.src)}
            >
              <div
                className="overflow-hidden"
                style={{ background: "oklch(0.08 0.010 260)" }}
              >
                <img
                  src={chart.src}
                  alt={chart.title}
                  className="chart-img"
                  loading="lazy"
                />
              </div>
              <div className="p-4">
                <h3
                  className="display-heading text-sm font-semibold mb-1"
                  style={{ color: "oklch(0.90 0.008 220)" }}
                >
                  {chart.title}
                </h3>
                <p
                  className="text-xs leading-relaxed"
                  style={{ color: "oklch(0.55 0.015 220)" }}
                >
                  {chart.desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {lightbox && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ background: "rgba(0,0,0,0.9)" }}
          onClick={() => setLightbox(null)}
        >
          <img
            src={lightbox}
            alt="Chart"
            className="max-w-full max-h-full rounded-lg"
            style={{ boxShadow: "0 0 40px rgba(0,212,255,0.2)" }}
          />
          <button
            className="absolute top-4 right-4 text-white text-2xl font-bold"
            onClick={() => setLightbox(null)}
          >
            ×
          </button>
        </div>
      )}
    </section>
  );
}
