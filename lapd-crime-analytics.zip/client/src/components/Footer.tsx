/**
 * Footer — Dark Intelligence theme footer
 */
import { Shield } from "lucide-react";

export default function Footer() {
  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <footer
      className="py-12 border-t"
      style={{
        background: "oklch(0.08 0.010 260)",
        borderColor: "var(--border)",
      }}
    >
      <div className="container">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div
                className="w-7 h-7 rounded flex items-center justify-center"
                style={{
                  background: "rgba(0,212,255,0.1)",
                  border: "1px solid rgba(0,212,255,0.3)",
                }}
              >
                <Shield
                  className="w-3.5 h-3.5"
                  style={{ color: "var(--neon-blue)" }}
                />
              </div>
              <span
                className="display-heading text-sm font-bold"
                style={{ color: "var(--neon-blue)" }}
              >
                LAPD ANALYTICS
              </span>
            </div>
            <p
              className="text-xs leading-relaxed"
              style={{ color: "oklch(0.50 0.015 220)" }}
            >
              Comprehensive data science analysis of LAPD crime incidents from
              2020 to 2025. Built with Python, Plotly, and React.
            </p>
          </div>

          {/* Navigation */}
          <div>
            <h4
              className="data-mono text-xs font-bold uppercase tracking-widest mb-3"
              style={{ color: "oklch(0.60 0.015 220)" }}
            >
              Sections
            </h4>
            <ul className="space-y-2">
              {[
                { id: "overview", label: "Overview" },
                { id: "eda", label: "EDA" },
                { id: "ml", label: "Machine Learning" },
                { id: "timeseries", label: "Time Series" },
                { id: "nlp", label: "NLP" },
                { id: "report", label: "Report" },
              ].map((item) => (
                <li key={item.id}>
                  <button
                    onClick={() => scrollTo(item.id)}
                    className="text-xs transition-colors duration-200"
                    style={{ color: "oklch(0.50 0.015 220)" }}
                    onMouseEnter={(e) =>
                      (e.currentTarget.style.color = "var(--neon-blue)")
                    }
                    onMouseLeave={(e) =>
                      (e.currentTarget.style.color = "oklch(0.50 0.015 220)")
                    }
                  >
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Data source */}
          <div>
            <h4
              className="data-mono text-xs font-bold uppercase tracking-widest mb-3"
              style={{ color: "oklch(0.60 0.015 220)" }}
            >
              Data Source
            </h4>
            <p
              className="text-xs leading-relaxed mb-2"
              style={{ color: "oklch(0.50 0.015 220)" }}
            >
              Crime Data from 2020 to Present
            </p>
            <a
              href="https://data.lacity.org"
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs transition-colors duration-200"
              style={{ color: "var(--neon-blue)" }}
            >
              data.lacity.org →
            </a>
            <div className="mt-4 space-y-1">
              {[
                { label: "Records", value: "1,004,991" },
                { label: "Period", value: "2020–2025" },
                { label: "Areas", value: "21 LAPD Divisions" },
              ].map((stat) => (
                <div key={stat.label} className="flex justify-between text-xs">
                  <span style={{ color: "oklch(0.45 0.015 220)" }}>
                    {stat.label}
                  </span>
                  <span
                    className="data-mono"
                    style={{ color: "oklch(0.65 0.015 220)" }}
                  >
                    {stat.value}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div
          className="pt-6 border-t flex flex-col md:flex-row justify-between items-center gap-3"
          style={{ borderColor: "var(--border)" }}
        >
          <p
            className="data-mono text-xs"
            style={{ color: "oklch(0.40 0.015 220)" }}
          >
            © 2026 LAPD Crime Analytics · Built with Manus AI
          </p>
          <p
            className="data-mono text-xs"
            style={{ color: "oklch(0.35 0.015 220)" }}
          >
            Data: Los Angeles Open Data Portal · Analysis: Python + Scikit-learn + Prophet
          </p>
        </div>
      </div>
    </footer>
  );
}
