/**
 * KPISection — Key performance indicators with neon glow cards
 */

const KPIS = [
  {
    value: "57.9%",
    label: "Property Crime",
    sub: "Most common category",
    color: "var(--neon-blue)",
    border: "rgba(0,212,255,0.3)",
    bg: "rgba(0,212,255,0.06)",
  },
  {
    value: "85.3%",
    label: "XGBoost Accuracy",
    sub: "Crime severity prediction",
    color: "var(--neon-green)",
    border: "rgba(16,185,129,0.3)",
    bg: "rgba(16,185,129,0.06)",
  },
  {
    value: "115,190",
    label: "Vehicle Thefts",
    sub: "#1 crime type",
    color: "var(--neon-amber)",
    border: "rgba(245,158,11,0.3)",
    bg: "rgba(245,158,11,0.06)",
  },
  {
    value: "32.6%",
    label: "Weapon Involved",
    sub: "Of all incidents",
    color: "var(--neon-red)",
    border: "rgba(239,68,68,0.3)",
    bg: "rgba(239,68,68,0.06)",
  },
  {
    value: "0.939",
    label: "AUC-ROC Score",
    sub: "XGBoost classifier",
    color: "var(--neon-blue)",
    border: "rgba(0,212,255,0.3)",
    bg: "rgba(0,212,255,0.06)",
  },
  {
    value: "Central",
    label: "Hotspot Area",
    sub: "69,670 incidents",
    color: "var(--neon-amber)",
    border: "rgba(245,158,11,0.3)",
    bg: "rgba(245,158,11,0.06)",
  },
  {
    value: "8,664",
    label: "Prophet MAE",
    sub: "Monthly forecast error",
    color: "var(--neon-green)",
    border: "rgba(16,185,129,0.3)",
    bg: "rgba(16,185,129,0.06)",
  },
  {
    value: "6",
    label: "LDA Topics",
    sub: "Crime description themes",
    color: "var(--neon-red)",
    border: "rgba(239,68,68,0.3)",
    bg: "rgba(239,68,68,0.06)",
  },
];

export default function KPISection() {
  return (
    <section id="overview" className="py-20">
      <div className="container">
        {/* Section header */}
        <div className="mb-12">
          <div
            className="data-mono text-xs tracking-widest uppercase mb-2"
            style={{ color: "var(--neon-blue)" }}
          >
            // KEY METRICS
          </div>
          <h2
            className="display-heading text-3xl md:text-4xl"
            style={{ color: "oklch(0.93 0.008 220)" }}
          >
            Project Overview
          </h2>
          <div className="section-divider mt-4 max-w-xs" />
        </div>

        {/* KPI grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-16">
          {KPIS.map((kpi, i) => (
            <div
              key={i}
              className="data-card p-5 rounded-lg transition-all duration-300"
              style={{
                borderColor: kpi.border,
                background: kpi.bg,
              }}
            >
              <div
                className="data-mono text-2xl md:text-3xl font-bold mb-1"
                style={{ color: kpi.color }}
              >
                {kpi.value}
              </div>
              <div
                className="font-semibold text-sm mb-1"
                style={{ color: "oklch(0.85 0.008 220)" }}
              >
                {kpi.label}
              </div>
              <div
                className="text-xs"
                style={{ color: "oklch(0.55 0.015 220)" }}
              >
                {kpi.sub}
              </div>
            </div>
          ))}
        </div>

        {/* Summary paragraph */}
        <div
          className="grid md:grid-cols-2 gap-8 p-6 rounded-lg"
          style={{
            background: "var(--surface-1)",
            border: "1px solid var(--border)",
          }}
        >
          <div>
            <h3
              className="display-heading text-xl mb-3"
              style={{ color: "oklch(0.93 0.008 220)" }}
            >
              Dataset Summary
            </h3>
            <p
              className="text-sm leading-relaxed"
              style={{ color: "oklch(0.65 0.015 220)" }}
            >
              The LAPD Crime Dataset covers over one million incidents across 21
              policing areas in Los Angeles from January 2020 through May 2025.
              It contains 28 original fields including crime codes, victim
              demographics, premise types, weapon usage, and geographic
              coordinates — enriched with 14 engineered features for analysis.
            </p>
          </div>
          <div>
            <h3
              className="display-heading text-xl mb-3"
              style={{ color: "oklch(0.93 0.008 220)" }}
            >
              Analytical Pipeline
            </h3>
            <p
              className="text-sm leading-relaxed"
              style={{ color: "oklch(0.65 0.015 220)" }}
            >
              This project applies a full data science pipeline: exploratory
              analysis with 20 visualizations, binary classification with
              Logistic Regression, Random Forest, and XGBoost, K-Means
              clustering, SARIMA and Prophet time series forecasting, and NLP
              with TF-IDF, bigrams, and LDA topic modeling on crime
              descriptions.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
