/**
 * LAPD Crime Analytics — Home Page
 * Design: Dark Intelligence / Data Noir
 * Typography: Space Grotesk (headings) + IBM Plex Mono (data) + Barlow (body)
 * Colors: Deep navy base, electric blue (#00d4ff) + amber (#f59e0b) neon accents
 */

import { useState, useEffect, useRef } from "react";
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import KPISection from "@/components/KPISection";
import EDASection from "@/components/EDASection";
import MLSection from "@/components/MLSection";
import TimeSeriesSection from "@/components/TimeSeriesSection";
import NLPSection from "@/components/NLPSection";
import ReportSection from "@/components/ReportSection";
import Footer from "@/components/Footer";

export default function Home() {
  const [activeSection, setActiveSection] = useState("hero");

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id);
          }
        });
      },
      { threshold: 0.3 }
    );

    const sections = document.querySelectorAll("section[id]");
    sections.forEach((s) => observer.observe(s));
    return () => observer.disconnect();
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground grid-bg">
      <Navbar activeSection={activeSection} />
      <HeroSection />
      <KPISection />
      <EDASection />
      <MLSection />
      <TimeSeriesSection />
      <NLPSection />
      <ReportSection />
      <Footer />
    </div>
  );
}
